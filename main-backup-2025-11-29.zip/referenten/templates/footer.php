        </main>

        <footer class="footer">
            <div class="footer-content">
                <p>
                    <a href="http://aktive.mensa.de/index.php">Im Überblick: Online Angebote im Verein</a>
                </p>
                <p class="footer-info">
                    Kurz-URL: <a href="http://j.mp/MinDRef">http://j.mp/MinDRef</a>
                </p>
                <p class="footer-note">
                    Diese Liste ist vereinsintern - nur Mensa-Mitglieder können sie abrufen.
                </p>
            </div>
        </footer>
    </div>

    <script src="js/referenten.js"></script>
</body>
</html>
