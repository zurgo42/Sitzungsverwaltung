<?php
/**
 * tab_protocol.php - Protokoll anzeigen
 */
?>

<h2>📄 Protokoll</h2>
<div class="info-box">Die Protokoll-Ansicht wird in einer zukünftigen Version implementiert.</div>